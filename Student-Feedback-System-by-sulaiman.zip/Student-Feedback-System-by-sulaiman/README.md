# Student-Feedback-System

This is an Online Portal For Students to give feedback to faculty at the end of the Semester, alongside features like Displaying Attendence, Displaying Academic Record, Displaying Information redgarding faculty and students have been added as well.

In the Feedback Section:-
Feedback can be given through star rating and comments could be added as well.
The Faculty would have access to only feedback, not the names of the students giving the feedback, but would be seperately stored in the DB.
Also, once if a students gives a feedback, won't be able to do it again.
