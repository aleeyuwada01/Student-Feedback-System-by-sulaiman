

    <!-- Navigation -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header" align="center"><font color="#00FF33">ONLINE FACULTY FEEDBACK SYSTEM</font> </h1>
                
            </div>
        </div>
        <!-- /.row -->

        <!-- Intro Content -->
        <div class="row" style="margin-bottom:50px;margin-left:50px">
           
               <P>Student Feedback system for College in PHP(SOurce code) 
Here we have developed the a faculty feedback system, which is generally used in the college to rate the faculty based on the performance...Here we have 2 modules such as administrator, student.

Administrator is the one who creates the student account by adding all student info and assigning the username and password. 
Admin als0 checks the result once all students entered the feedback..
We can start the development from the login page, where we have given the option to login as admin and student...Here since we have only one admin account, so no need to create the a database to store admin info...so the admin username is "admin" and password is "sandeep"...select admin in the radio button and login 

You can perform all admin actions such as login to the account and check result..

I fyou entered the student user and password and selected student option, then it will show all student information and let you enter the feedback based on the subject..

Before we can look into the php code, you need to create a database called "feed" with two tables in it..one as student and another one as take
</P> 
               
            </div>
        </div>
        <!-- /.row -->

        <!-- Footer -->
     